package com.mycompany.chatapp;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class RegistrationTest {
    private Rregistration validUser;

    @BeforeEach
    void setUp() {
        validUser = new Rregistration("Thabo", "Nkosi", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
    }

    @Test void acceptsUsernameWithUnderscoreAtFiveCharacters() { assertTrue(validUser.checkUserName()); }
    @Test void rejectsUsernameWithoutUnderscore() {
        assertFalse(new Rregistration("A", "B", "kyle!", "Ch&&sec@ke99!", "+27838968976").checkUserName());
    }
    @Test void rejectsUsernameLongerThanFiveCharacters() {
        assertFalse(new Rregistration("A", "B", "user_name", "Ch&&sec@ke99!", "+27838968976").checkUserName());
    }
    @Test void acceptsComplexPassword() { assertTrue(validUser.checkPasswordComplexity()); }
    @Test void rejectsPasswordWithoutComplexity() {
        assertFalse(new Rregistration("A", "B", "kyl_1", "password", "+27838968976").checkPasswordComplexity());
    }
    @Test void acceptsInternationalSouthAfricanNumber() { assertTrue(validUser.checkCellPhoneNumber()); }
    @Test void rejectsLocalNumberWithoutCountryCode() {
        assertFalse(new Rregistration("A", "B", "kyl_1", "Ch&&sec@ke99!", "08966553").checkCellPhoneNumber());
    }
    @Test void registrationReturnsRequiredSuccessMessages() {
        assertEquals("Username successfully captured.\nPassword successfully captured.\nCell number successfully captured.\nUser registered successfully.", validUser.registerUser());
    }
    @Test void registrationReturnsRequiredUsernameError() {
        Rregistration user = new Rregistration("A", "B", "kyle!!!!!!!", "Ch&&sec@ke99!", "+27838968976");
        assertEquals("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.", user.registerUser());
    }
    @Test void registrationReturnsRequiredPasswordError() {
        Rregistration user = new Rregistration("A", "B", "kyl_1", "password", "+27838968976");
        assertEquals("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.", user.registerUser());
    }
    @Test void loginSucceedsOnlyForRegisteredCredentials() {
        assertTrue(validUser.loginUser("kyl_1", "Ch&&sec@ke99!"));
        assertFalse(validUser.loginUser("wrong", "Ch&&sec@ke99!"));
        assertFalse(validUser.loginUser("kyl_1", "wrong"));
    }
    @Test void returnsRequiredLoginMessages() {
        assertEquals("Welcome Thabo Nkosi, it is great to see you.", validUser.returnLoginStatus(true));
        assertEquals("Username or password incorrect, please try again.", validUser.returnLoginStatus(false));
    }
}
