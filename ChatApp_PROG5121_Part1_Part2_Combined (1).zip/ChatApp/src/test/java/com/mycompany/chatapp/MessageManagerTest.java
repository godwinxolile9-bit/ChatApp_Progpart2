package com.mycompany.chatapp;

import static org.junit.jupiter.api.Assertions.*;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class MessageManagerTest {
    private MessageManager manager;
    private Message sent;
    private Message longStored;
    private Message disregarded;
    private Message fourthSent;
    private Message secondStored;

    @BeforeEach void setUp() {
        sent = new Message(1, "+27834557896", "Did you get the cake?", "1000000001", "Thabo Nkosi");
        sent.setStatus("Sent");
        longStored = new Message(2, "+27838884567", "Where are you? You are late! I have asked you to be on time.", "2000000002", "Thabo Nkosi");
        longStored.setStatus("Stored");
        disregarded = new Message(3, "+27834484567", "Yohoooo, I am at your gate.", "3000000003", "Thabo Nkosi");
        disregarded.setStatus("Disregarded");
        fourthSent = new Message(4, "+27838884567", "It is dinner time!", "0838884567", "Thabo Nkosi");
        fourthSent.setStatus("Sent");
        secondStored = new Message(5, "+27838884567", "Ok, I am leaving without you.", "5000000005", "Thabo Nkosi");
        secondStored.setStatus("Stored");
        manager = new MessageManager(new java.util.ArrayList<>(List.of(sent, longStored, disregarded, fourthSent, secondStored)));
    }

    @Test void buildsStatusHashAndIdArrays() {
        assertEquals(2, manager.getSentMessages().length);
        assertEquals(1, manager.getDisregardedMessages().length);
        assertEquals(2, manager.getStoredMessages().length);
        assertEquals(5, manager.getMessageHashes().length);
        assertEquals(5, manager.getMessageIDs().length);
        assertEquals(List.of("Did you get the cake?", "It is dinner time!"),
                java.util.Arrays.stream(manager.getSentMessages()).map(Message::getMessage).toList());
    }
    @Test void findsLongestStoredMessage() { assertEquals(longStored.getMessage(), manager.longestStoredMessage().orElseThrow().getMessage()); }
    @Test void searchesByMessageId() {
        assertEquals(fourthSent.getMessage(), manager.findByID("0838884567").orElseThrow().getMessage());
    }
    @Test void findsSentAndStoredMessagesForRecipient() {
        assertEquals(List.of(longStored.getMessage(), secondStored.getMessage()),
                manager.findByRecipient("+27838884567").stream().map(Message::getMessage).toList());
    }
    @Test void deletesStoredMessageByHashAndRefreshesArrays() {
        assertEquals(longStored.getMessage(), manager.deleteByHash(longStored.getMessageHash()).orElseThrow().getMessage());
        assertEquals(1, manager.getStoredMessages().length);
        assertTrue(manager.findByID(longStored.getMessageID()).isEmpty());
    }
    @Test void reportContainsSentAndStoredMessageDetails() {
        String report = manager.createReport();
        assertTrue(report.contains(sent.getMessageHash()));
        assertTrue(report.contains(sent.getRecipient()));
        assertTrue(report.contains(longStored.getMessage()));
        assertTrue(report.contains(fourthSent.getMessage()));
        assertFalse(report.contains(disregarded.getMessage()));
    }
}
