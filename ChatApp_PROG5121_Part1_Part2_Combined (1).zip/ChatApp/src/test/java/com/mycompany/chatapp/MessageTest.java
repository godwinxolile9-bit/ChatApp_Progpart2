package com.mycompany.chatapp;

import static org.junit.jupiter.api.Assertions.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class MessageTest {
    @TempDir Path tempDir;

    @Test void messageIdIsTenDigits() { assertTrue(new Message(1, "+27718693002", "Hello").checkMessageID()); }
    @Test void recipientValidationAcceptsInternationalNumber() {
        assertEquals("Cell phone number successfully captured.", new Message(1, "+27718693002", "Hello").checkRecipientCell());
    }
    @Test void recipientValidationRejectsLocalNumber() {
        assertTrue(new Message(1, "08575975889", "Hello").checkRecipientCell().startsWith("Cell phone number is incorrectly formatted"));
    }
    @Test void acceptsMessageAt250Characters() {
        assertEquals("Message ready to send.", new Message(1, "+27718693002", "x".repeat(250)).checkMessageLength());
    }
    @Test void reportsExactExcessLength() {
        assertEquals("Message exceeds 250 characters by 3; please reduce the size.", new Message(1, "+27718693002", "x".repeat(253)).checkMessageLength());
    }
    @Test void createsExpectedMessageHash() {
        Message message = new Message(0, "+27718693002", "Hi Mike, can you join us for dinner tonight?", "0012345678", "Thabo Nkosi");
        assertEquals("00:0:HITONIGHT", message.createMessageHash());
    }
    @Test void supportsSendDiscardAndStoreChoices() {
        Message sent = new Message(1, "+27718693002", "Hello");
        assertEquals("Message successfully sent.", sent.SentMessage(1));
        assertEquals("Sent", sent.getStatus());
        assertEquals("Press 0 to delete the message.", sent.SentMessage(2));
        assertEquals("Disregarded", sent.getStatus());
        assertEquals("Message successfully stored.", sent.SentMessage(3));
        assertEquals("Stored", sent.getStatus());
    }
    @Test void storesAndLoadsJsonWithPunctuation() throws IOException {
        Message message = new Message(1, "+27718693002", "Hi, Mike! It's dinner time.", "0012345678", "Thabo Nkosi");
        message.setStatus("Stored");
        MessageStore store = new MessageStore(tempDir.resolve("messages.json"));
        store.save(List.of(message));
        List<Message> loaded = store.load();
        assertEquals(1, loaded.size());
        assertEquals(message.getMessage(), loaded.get(0).getMessage());
        assertEquals("Stored", loaded.get(0).getStatus());
        assertTrue(Files.readString(tempDir.resolve("messages.json")).contains("\"message\""));
    }
}
