package com.mycompany.chatapp;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Small JSON persistence helper; escapes strings so messages remain valid JSON. */
public final class MessageStore {
    private final Path file;

    public MessageStore(Path file) { this.file = file; }

    public void save(List<Message> messages) throws IOException {
        StringBuilder json = new StringBuilder("[\n");
        for (int i = 0; i < messages.size(); i++) {
            Message m = messages.get(i);
            json.append("  {\n")
                .append("    \"messageID\": \"").append(escape(m.getMessageID())).append("\",\n")
                .append("    \"messageNumber\": ").append(m.getMessageNumber()).append(",\n")
                .append("    \"messageHash\": \"").append(escape(m.getMessageHash())).append("\",\n")
                .append("    \"sender\": \"").append(escape(m.getSender())).append("\",\n")
                .append("    \"recipient\": \"").append(escape(m.getRecipient())).append("\",\n")
                .append("    \"message\": \"").append(escape(m.getMessage())).append("\",\n")
                .append("    \"status\": \"").append(escape(m.getStatus())).append("\"\n")
                .append("  }").append(i + 1 < messages.size() ? "," : "").append("\n");
        }
        json.append("]\n");
        Path parent = file.toAbsolutePath().getParent();
        if (parent != null) Files.createDirectories(parent);
        Files.writeString(file, json.toString(), StandardCharsets.UTF_8);
    }

    /** Reads JSON objects written by save(). Supports escaped quotes and backslashes. */
    public List<Message> load() throws IOException {
        List<Message> result = new ArrayList<>();
        if (!Files.exists(file)) return result;
        String json = Files.readString(file, StandardCharsets.UTF_8);
        int cursor = 0;
        while ((cursor = json.indexOf('{', cursor)) >= 0) {
            int end = findObjectEnd(json, cursor);
            if (end < 0) break;
            String object = json.substring(cursor + 1, end);
            String id = stringField(object, "messageID");
            String numberText = numberField(object, "messageNumber");
            String sender = stringField(object, "sender");
            String recipient = stringField(object, "recipient");
            String message = stringField(object, "message");
            String status = stringField(object, "status");
            if (!id.isEmpty() && !numberText.isEmpty()) {
                try {
                    Message loaded = new Message(Integer.parseInt(numberText), recipient, message, id, sender);
                    loaded.setStatus(status);
                    result.add(loaded);
                } catch (NumberFormatException ignored) {
                    // Ignore malformed entries instead of crashing the application.
                }
            }
            cursor = end + 1;
        }
        return result;
    }

    private int findObjectEnd(String json, int start) {
        boolean quoted = false, escaped = false;
        for (int i = start + 1; i < json.length(); i++) {
            char c = json.charAt(i);
            if (escaped) { escaped = false; continue; }
            if (c == '\\' && quoted) { escaped = true; continue; }
            if (c == '"') quoted = !quoted;
            else if (c == '}' && !quoted) return i;
        }
        return -1;
    }

    private String stringField(String object, String name) {
        String key = "\"" + name + "\"";
        int index = object.indexOf(key);
        if (index < 0) return "";
        index = object.indexOf(':', index + key.length()) + 1;
        while (index < object.length() && Character.isWhitespace(object.charAt(index))) index++;
        if (index >= object.length() || object.charAt(index) != '"') return "";
        StringBuilder value = new StringBuilder();
        boolean escaped = false;
        for (int i = index + 1; i < object.length(); i++) {
            char c = object.charAt(i);
            if (escaped) {
                value.append(switch (c) { case 'n' -> '\n'; case 'r' -> '\r'; case 't' -> '\t'; default -> c; });
                escaped = false;
            } else if (c == '\\') escaped = true;
            else if (c == '"') return value.toString();
            else value.append(c);
        }
        return value.toString();
    }

    private String numberField(String object, String name) {
        String key = "\"" + name + "\"";
        int index = object.indexOf(key);
        if (index < 0) return "";
        index = object.indexOf(':', index + key.length()) + 1;
        while (index < object.length() && Character.isWhitespace(object.charAt(index))) index++;
        int end = index;
        while (end < object.length() && Character.isDigit(object.charAt(end))) end++;
        return object.substring(index, end);
    }

    private String escape(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
    }
}
