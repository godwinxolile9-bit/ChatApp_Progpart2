package com.mycompany.chatapp;

import java.util.regex.Pattern;

/** Registration and login validation for the QuickChat console application. */
public class Rregistration {
    private static final Pattern SA_MOBILE_PATTERN = Pattern.compile("^\\+27[6-8]\\d{8}$");
    private final String firstName;
    private final String lastName;
    private final String username;
    private final String password;
    private final String cellPhoneNumber;

    public Rregistration(String firstName, String lastName, String username,
                         String password, String cellPhoneNumber) {
        this.firstName = firstName == null ? "" : firstName.trim();
        this.lastName = lastName == null ? "" : lastName.trim();
        this.username = username == null ? "" : username;
        this.password = password == null ? "" : password;
        this.cellPhoneNumber = cellPhoneNumber == null ? "" : cellPhoneNumber.trim();
    }

    /** Username must contain an underscore and be at most five characters. */
    public boolean checkUserName() {
        return username.contains("_") && username.length() <= 5;
    }

    /** Password needs 8+ characters, uppercase, digit and non-alphanumeric character. */
    public boolean checkPasswordComplexity() {
        if (password.length() < 8) return false;
        boolean uppercase = false;
        boolean digit = false;
        boolean special = false;
        for (char character : password.toCharArray()) {
            uppercase |= Character.isUpperCase(character);
            digit |= Character.isDigit(character);
            special |= !Character.isLetterOrDigit(character);
        }
        return uppercase && digit && special;
    }

    /**
     * Validates a South African mobile number in international format.
     * Regex format: +27 followed by a mobile prefix (6, 7 or 8) and eight digits.
     * Regular-expression syntax reference: Oracle (2024), Java SE 21 API,
     * java.util.regex.Pattern, https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/regex/Pattern.html
     * (accessed 19 October 2026).
     */
    public boolean checkCellPhoneNumber() {
        return SA_MOBILE_PATTERN.matcher(cellPhoneNumber).matches();
    }

    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber()) {
            return "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
        }
        return "Username successfully captured.\nPassword successfully captured.\nCell number successfully captured.\nUser registered successfully.";
    }

    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return username.equals(enteredUsername) && password.equals(enteredPassword)
                && checkUserName() && checkPasswordComplexity() && checkCellPhoneNumber();
    }

    public String returnLoginStatus(boolean loginSuccessful) {
        return loginSuccessful
                ? "Welcome " + firstName + " " + lastName + ", it is great to see you."
                : "Username or password incorrect, please try again.";
    }

    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getUsername() { return username; }
    public String getCellPhoneNumber() { return cellPhoneNumber; }
}
