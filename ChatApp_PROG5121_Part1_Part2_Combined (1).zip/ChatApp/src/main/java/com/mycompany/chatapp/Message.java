package com.mycompany.chatapp;

import java.security.SecureRandom;
import java.util.Locale;
import java.util.Objects;
import java.util.regex.Pattern;

/** Represents a single QuickChat message and its delivery choice. */
public class Message {
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final Pattern SA_MOBILE_PATTERN = Pattern.compile("^\\+27[6-8]\\d{8}$");
    private final String messageID;
    private final int messageNumber;
    private final String recipient;
    private final String message;
    private final String messageHash;
    private String status;
    private final String sender;

    public Message(int messageNumber, String recipient, String message) {
        this(messageNumber, recipient, message, generateMessageID(), "Sender");
    }

    public Message(int messageNumber, String recipient, String message, String sender) {
        this(messageNumber, recipient, message, generateMessageID(), sender);
    }

    public Message(int messageNumber, String recipient, String message, String messageID, String sender) {
        this.messageNumber = messageNumber;
        this.recipient = recipient == null ? "" : recipient.trim();
        this.message = message == null ? "" : message.trim();
        this.messageID = Objects.requireNonNull(messageID, "messageID");
        this.sender = sender == null ? "Sender" : sender;
        this.messageHash = buildMessageHash(this.messageID, this.messageNumber, this.message);
        this.status = "Pending";
    }

    private static String generateMessageID() {
        long value = 1_000_000_000L + RANDOM.nextLong(9_000_000_000L);
        return Long.toString(value);
    }

    /** A valid generated or supplied message ID is exactly ten numeric digits. */
    public boolean checkMessageID() {
        return messageID.matches("\\d{10}");
    }

    public String checkRecipientCell() {
        return SA_MOBILE_PATTERN.matcher(recipient).matches()
                ? "Cell phone number successfully captured."
                : "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    public boolean isRecipientValid() {
        return SA_MOBILE_PATTERN.matcher(recipient).matches();
    }

    public String checkMessageLength() {
        if (message.length() <= 250) return "Message ready to send.";
        return "Message exceeds 250 characters by " + (message.length() - 250) + "; please reduce the size.";
    }

    /** Hash format: first two ID digits : message number : first and last words, uppercase. */
    public String createMessageHash() {
        return buildMessageHash(messageID, messageNumber, message);
    }

    private static String buildMessageHash(String id, int number, String payload) {
        String[] words = payload.trim().split("\\s+");
        String first = words.length == 0 || words[0].isBlank() ? "" : cleanWord(words[0]);
        String last = words.length == 0 || words[words.length - 1].isBlank()
                ? "" : cleanWord(words[words.length - 1]);
        return id.substring(0, Math.min(2, id.length())) + ":"
                + number + ":" + (first + last).toUpperCase(Locale.ROOT);
    }

    private static String cleanWord(String word) {
        return word.replaceAll("[^\\p{L}\\p{N}]", "");
    }

    /** Converts a numeric menu choice to the exact required response and status. */
    public String SentMessage(int choice) {
        return switch (choice) {
            case 1 -> { status = "Sent"; yield "Message successfully sent."; }
            case 2 -> { status = "Disregarded"; yield "Press 0 to delete the message."; }
            case 3 -> { status = "Stored"; yield "Message successfully stored."; }
            default -> "Invalid choice. Please select 1, 2, or 3.";
        };
    }

    public String SentMessage() {
        return "Message status: " + status;
    }

    public String printMessages() {
        return "Message ID: " + messageID + System.lineSeparator()
                + "Message Hash: " + messageHash + System.lineSeparator()
                + "Recipient: " + recipient + System.lineSeparator()
                + "Message: " + message;
    }

    public int returnTotalMessagess() { return "Sent".equals(status) ? 1 : 0; }
    public String getMessageID() { return messageID; }
    public int getMessageNumber() { return messageNumber; }
    public String getRecipient() { return recipient; }
    public String getMessage() { return message; }
    public String getMessageHash() { return messageHash; }
    public String getStatus() { return status; }
    public String getSender() { return sender; }
    public void setStatus(String status) { this.status = status; }
}
