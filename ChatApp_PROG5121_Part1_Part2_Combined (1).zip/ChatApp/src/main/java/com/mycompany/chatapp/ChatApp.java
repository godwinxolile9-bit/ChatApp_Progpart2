package com.mycompany.chatapp;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/** Console entry point for registration, login and the QuickChat message features. */
public class ChatApp {
    private final Scanner scanner;
    private final List<Message> messages = new ArrayList<>();
    private final MessageManager manager = new MessageManager(messages);
    private final MessageStore store = new MessageStore(Path.of("messages.json"));
    private String senderName = "Sender";

    public ChatApp(Scanner scanner) { this.scanner = scanner; }

    public static void main(String[] args) {
        new ChatApp(new Scanner(System.in)).run();
    }

    public void run() {
        System.out.println("====================================\n       REGISTRATION AND LOGIN\n====================================");
        System.out.print("Enter your first name: "); String first = scanner.nextLine().trim();
        System.out.print("Enter your last name: "); String last = scanner.nextLine().trim();
        System.out.print("Enter a username: "); String username = scanner.nextLine().trim();
        System.out.print("Enter a password: "); String password = scanner.nextLine();
        System.out.print("Enter your South African cellphone number (+27...): "); String phone = scanner.nextLine().trim();

        Rregistration registration = new Rregistration(first, last, username, password, phone);
        System.out.println(registration.registerUser());
        if (!registration.checkUserName() || !registration.checkPasswordComplexity()
                || !registration.checkCellPhoneNumber()) return;

        System.out.println("\n================ LOGIN ================");
        System.out.print("Enter your username: "); String loginUsername = scanner.nextLine();
        System.out.print("Enter your password: "); String loginPassword = scanner.nextLine();
        boolean authenticated = registration.loginUser(loginUsername, loginPassword);
        System.out.println(registration.returnLoginStatus(authenticated));
        if (!authenticated) return;
        senderName = registration.getFirstName() + " " + registration.getLastName();
        try { messages.addAll(store.load()); }
        catch (IOException ex) { System.out.println("Stored messages could not be loaded: " + ex.getMessage()); }
        manager.refreshArrays();
        chatMenu();
    }

    private void chatMenu() {
        System.out.println("\nWelcome to QuickChat.");
        int maximum = readInt("How many messages would you like to enter this session? ", 0, 1000);
        int sentThisSession = 0;
        boolean running = true;
        while (running) {
            System.out.println("\n1) Send Messages\n2) Message Tools (recent messages, search, delete, report)\n3) Quit");
            int option = readInt("Choose an option: ", 1, 3);
            switch (option) {
                case 1 -> {
                    if (sentThisSession >= maximum) {
                        System.out.println("You have reached the number of messages selected for this session.");
                    } else {
                        // The for-loop follows the assigned message count and increments the message number.
                        for (int i = sentThisSession; i < maximum; i++) {
                            int created = sendOneMessage(messages.size() + 1);
                            sentThisSession += created;
                            if (created == 0) {
                                System.out.println("This message was not added. You can try again from the menu.");
                                break;
                            }
                        }
                    }
                }
                case 2 -> storedMessagesMenu();
                case 3 -> running = false;
                default -> System.out.println("Please select a valid option.");
            }
        }
        manager.refreshArrays();
        long totalSent = manager.getSentMessages().length;
        System.out.println("Total messages sent: " + totalSent);
        try { store.save(messages); System.out.println("Messages saved to messages.json."); }
        catch (IOException ex) { System.out.println("Could not save messages: " + ex.getMessage()); }
        System.out.println("Goodbye.");
    }

    private int sendOneMessage(int number) {
        System.out.print("Enter recipient cellphone number (+27...): "); String recipient = scanner.nextLine().trim();
        Message draft = new Message(number, recipient, "", "0000000000", senderName);
        String recipientResult = draft.checkRecipientCell();
        if (!draft.isRecipientValid()) { System.out.println(recipientResult); return 0; }
        System.out.print("Enter your message (maximum 250 characters): "); String body = scanner.nextLine();
        Message message = new Message(number, recipient, body, senderName);
        String lengthResult = message.checkMessageLength();
        if (!"Message ready to send.".equals(lengthResult)) { System.out.println(lengthResult); return 0; }
        System.out.println("Message Hash: " + message.getMessageHash());
        System.out.println("1) Send Message\n2) Disregard Message\n3) Store Message to send later");
        int choice = readInt("Choose an option: ", 1, 3);
        System.out.println(message.SentMessage(choice));
        if ("Sent".equals(message.getStatus()) || "Stored".equals(message.getStatus())
                || "Disregarded".equals(message.getStatus())) messages.add(message);
        manager.refreshArrays();
        System.out.println(message.printMessages());
        try { store.save(messages); } catch (IOException ex) { System.out.println("Save failed: " + ex.getMessage()); }
        return 1;
    }

    private void storedMessagesMenu() {
        boolean back = false;
        while (!back) {
            System.out.println("\nMESSAGE TOOLS\n1) Show recently sent messages\n2) Display sender and recipient"
                    + "\n3) Longest stored message\n4) Search message ID\n5) Search recipient"
                    + "\n6) Delete by message hash\n7) Display message report\n8) Back");
            int choice = readInt("Choose an option: ", 1, 8);
            manager.refreshArrays();
            List<Message> stored = List.of(manager.getStoredMessages());
            switch (choice) {
                case 1 -> {
                    Message[] sent = manager.getSentMessages();
                    if (sent.length == 0) System.out.println("No messages have been sent yet.");
                    else for (Message message : sent) System.out.println(message.printMessages());
                }
                case 2 -> stored.forEach(m -> System.out.println("Sender: " + m.getSender() + " | Recipient: " + m.getRecipient()));
                case 3 -> manager.longestStoredMessage()
                        .ifPresentOrElse(m -> System.out.println(m.getMessage()), () -> System.out.println("No stored messages."));
                case 4 -> {
                    System.out.print("Enter message ID: "); String id = scanner.nextLine().trim();
                    manager.findByID(id)
                            .ifPresentOrElse(m -> System.out.println("Recipient: " + m.getRecipient() + "\nMessage: " + m.getMessage()),
                                    () -> System.out.println("Message ID not found."));
                }
                case 5 -> {
                    System.out.print("Enter recipient number: "); String recipient = scanner.nextLine().trim();
                    List<Message> matches = manager.findByRecipient(recipient);
                    if (matches.isEmpty()) System.out.println("No sent or stored messages found for that recipient.");
                    else matches.forEach(m -> System.out.println(m.getMessage()));
                }
                case 6 -> {
                    System.out.print("Enter message hash: "); String hash = scanner.nextLine().trim();
                    Message match = manager.deleteByHash(hash).orElse(null);
                    if (match == null) System.out.println("Stored message hash not found.");
                    else System.out.println("Message: \"" + match.getMessage() + "\" successfully deleted.");
                }
                case 7 -> {
                    String report = manager.createReport();
                    System.out.println(report.isEmpty() ? "No sent or stored messages." : report);
                }
                case 8 -> back = true;
                default -> System.out.println("Please select a valid option.");
            }
            try { store.save(messages); } catch (IOException ex) { System.out.println("Save failed: " + ex.getMessage()); }
        }
    }

    private int readInt(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String value = scanner.nextLine().trim();
            try {
                int number = Integer.parseInt(value);
                if (number >= min && number <= max) return number;
            } catch (NumberFormatException ignored) { /* Ask again below. */ }
            System.out.println("Enter a number from " + min + " to " + max + ".");
        }
    }
}
