package com.mycompany.chatapp;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** Maintains the five data arrays and implements the final PoE search/report operations. */
public final class MessageManager {
    private final List<Message> messages;
    private Message[] sentMessages = new Message[0];
    private Message[] disregardedMessages = new Message[0];
    private Message[] storedMessages = new Message[0];
    private String[] messageHashes = new String[0];
    private String[] messageIDs = new String[0];

    public MessageManager() { this(new ArrayList<>()); }
    public MessageManager(List<Message> messages) {
        this.messages = messages;
        refreshArrays();
    }

    public void add(Message message) { messages.add(message); refreshArrays(); }
    public List<Message> getMessages() { return List.copyOf(messages); }
    public Message[] getSentMessages() { return sentMessages.clone(); }
    public Message[] getDisregardedMessages() { return disregardedMessages.clone(); }
    public Message[] getStoredMessages() { return storedMessages.clone(); }
    public String[] getMessageHashes() { return messageHashes.clone(); }
    public String[] getMessageIDs() { return messageIDs.clone(); }

    public void refreshArrays() {
        sentMessages = messages.stream().filter(m -> "Sent".equals(m.getStatus())).toArray(Message[]::new);
        disregardedMessages = messages.stream().filter(m -> "Disregarded".equals(m.getStatus())).toArray(Message[]::new);
        storedMessages = messages.stream().filter(m -> "Stored".equals(m.getStatus())).toArray(Message[]::new);
        messageHashes = messages.stream().map(Message::getMessageHash).toArray(String[]::new);
        messageIDs = messages.stream().map(Message::getMessageID).toArray(String[]::new);
    }

    public Optional<Message> longestStoredMessage() {
        return List.of(storedMessages).stream().max((a, b) -> Integer.compare(a.getMessage().length(), b.getMessage().length()));
    }

    public Optional<Message> findByID(String id) {
        for (int i = 0; i < messageIDs.length; i++) if (messageIDs[i].equals(id)) return Optional.of(messages.get(i));
        return Optional.empty();
    }

    public List<Message> findByRecipient(String recipient) {
        List<Message> found = new ArrayList<>();
        for (Message message : messages) {
            if (message.getRecipient().equals(recipient)
                    && ("Sent".equals(message.getStatus()) || "Stored".equals(message.getStatus()))) found.add(message);
        }
        return found;
    }

    public Optional<Message> deleteByHash(String hash) {
        for (int i = 0; i < messageHashes.length; i++) {
            if (messageHashes[i].equalsIgnoreCase(hash) && "Stored".equals(messages.get(i).getStatus())) {
                Message deleted = messages.remove(i);
                refreshArrays();
                return Optional.of(deleted);
            }
        }
        return Optional.empty();
    }

    public String createReport() {
        StringBuilder report = new StringBuilder();
        for (Message message : messages) {
            if ("Sent".equals(message.getStatus()) || "Stored".equals(message.getStatus())) {
                report.append("Message Hash: ").append(message.getMessageHash()).append(System.lineSeparator())
                        .append("Recipient: ").append(message.getRecipient()).append(System.lineSeparator())
                        .append("Message: ").append(message.getMessage()).append(System.lineSeparator())
                        .append("Status: ").append(message.getStatus()).append(System.lineSeparator()).append(System.lineSeparator());
            }
        }
        return report.toString().trim();
    }
}
