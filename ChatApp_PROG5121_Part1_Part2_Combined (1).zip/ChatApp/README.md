# QuickChat — PROG5121

A Java console application for the Programming 1A practical PoE. It combines **Part 1 (registration and login)**, **Part 2 (QuickChat messages)**, and the final PoE message-array/report operations. It includes registration/login validation, message creation and hashing, send/discard/store choices, JSON persistence, searches/deletion/reports, JUnit 5 tests, and a GitHub Actions workflow.

## Requirements
- JDK 21
- Maven 3.9+

## Run and test
Open a terminal in this project folder. With JDK 21 and Maven 3.9+ installed, run:
```bash
mvn clean test
mvn exec:java -Dexec.mainClass=com.mycompany.chatapp.ChatApp
```

The full JUnit suite still needs to be run in an environment with Maven and dependency access. Production Java sources were compiled with Java 21 and a console registration/login/send/quit smoke test was completed in the preparation environment.

The app is console-only as required. Message data is persisted in `messages.json` in the working directory. Use a South African mobile number in international form, for example `+27821234567`.

## Main classes
- `Rregistration`: registration rules and login authentication.
- `Message`: message ID, recipient validation, 250-character limit, hash and send status.
- `MessageStore`: JSON file persistence.
- `ChatApp`: console menus and stored-message actions.

## Note about the assignment specification
The brief contains slightly different wording for some phone-number error messages and describes a ten-character limit while its South African examples include `+27` and nine further digits. This implementation follows the examples and validates `+27` followed by a mobile prefix and eight further digits.
