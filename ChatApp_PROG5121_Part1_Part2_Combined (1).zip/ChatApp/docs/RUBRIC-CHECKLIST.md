# PROG5121 implementation checklist

Use this checklist to verify the application before submission. The checklist is a guide, not a claim that an external marker has awarded marks.

## Part 1 — Registration and login
- [x] Username includes `_` and is no longer than five characters.
- [x] Password has at least eight characters, an uppercase letter, a digit and a special character.
- [x] South African mobile number is validated in international format with a regular expression.
- [x] Registration returns success/error messages.
- [x] Login compares the registered username and password and returns the specified status message.
- [x] Unit tests cover valid and invalid registration and login.

## Part 2 — Messages
- [x] Main console menu uses numeric options 1–3: send messages, open message tools, and quit.
- [x] A `while` loop keeps the application running until the user chooses quit.
- [x] A `for` loop processes the number of messages selected for the session.
- [x] Message tools display recently sent messages and provide the final PoE operations.
- [x] Session message limit is enforced.
- [x] Message ID, hash, recipient and body are represented by the `Message` class.
- [x] Message length and recipient format are validated.
- [x] Send, disregard and store choices update message status.
- [x] JSON persistence is implemented.
- [x] Unit tests cover validation, hash generation, status choices and JSON round-trip.

## Final PoE — Arrays and reports
- [x] Arrays are rebuilt from live message data rather than hard-coded values.
- [x] Stored-message menu displays sender/recipient and longest stored message.
- [x] Search by ID and recipient is implemented.
- [x] Stored messages can be deleted by hash.
- [x] Report includes message hash, recipient, body and status for sent/stored messages.
- [x] Unit tests cover array population, longest message, searches, deletion and reporting.

## Before submission
- [ ] Run `mvn clean test` locally and confirm all tests pass.
- [ ] Push the intended repository to GitHub and confirm the Actions workflow is green.
- [ ] Record and upload your own voice-over demonstration showing the app running and explaining the logic.
- [ ] Submit the correct GitHub repository URL and presentation link through the required student portal.
