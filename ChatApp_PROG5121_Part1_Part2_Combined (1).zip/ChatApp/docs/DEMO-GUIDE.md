# Suggested demonstration outline

Record this in your own voice, as required by the assignment. Explain the code in your own words rather than reading a script verbatim.

1. Show the Maven project structure and explain the role of `ChatApp`, `Rregistration`, `Message`, `MessageManager` and `MessageStore`.
2. Demonstrate a valid registration, then an invalid username, an invalid password and an invalid local-format phone number.
3. Log in with the correct credentials, then show a failed login in a fresh run.
4. Choose a session message limit and demonstrate sending, disregarding and storing messages.
5. Explain how the ten-digit ID and uppercase hash are created and how the 250-character limit is checked.
6. Open `messages.json` and explain how the application saves and loads stored messages.
7. Demonstrate the stored-message menu: sender/recipient, longest stored message, ID search, recipient search, delete by hash and report.
8. Run `mvn clean test` and show the GitHub Actions workflow result after pushing.
9. Briefly explain a few tests and what each assertion verifies.
